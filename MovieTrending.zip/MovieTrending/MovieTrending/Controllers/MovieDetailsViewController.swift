//
//  MovieDetailsViewController.swift
//  MovieTrending
//
//  Created by Yersultan Mendigali on 27.04.2021.
//

import UIKit
import Alamofire
import Kingfisher

class MovieDetailsViewController: UIViewController {
    
    private let MOVIE_DETEAIL_URL: String = "https://api.themoviedb.org/3/movie/"
    private let API_KEY = "?api_key=4f02196edbf94fa32ed2e913d93e4d42"
    
    public var movieId: Int?
    private var movie: MovieDetail?
    
    @IBOutlet private weak var ratingContainer: UIView!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var releaseDateLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!
    
    private var TRENDING_MOVIE_BY_ID = "https://api.themoviedb.org/3/movie/"
    
    private var details: MovieDetail?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getMovieDetails()
        ratingContainer.layer.cornerRadius = 30
        ratingContainer.layer.masksToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let movieId = movieId {
            if let _ = CoreDataManager.shared.findMovie(with: movieId) {
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
            } else {
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
            }
        }
    }

    
    @IBAction func favoriteButtonPressed(_ sender: UIButton) {
        if let movieId = movieId {
            if let _ = CoreDataManager.shared.findMovie(with: movieId) {
                CoreDataManager.shared.deleteMovie(with: movieId)
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
            } else {
                if var details = details {
                    details.id = movieId
                    CoreDataManager.shared.addMovie(details)
                    favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                }
            }
        }
    }
}

extension MovieDetailsViewController {
    private func getMovieDetails() {
        if let movieId = movieId {
            AF.request(MOVIE_DETEAIL_URL + "\(movieId)" + API_KEY, method: .get, parameters: [:]).responseJSON { [weak self] response in
                switch response.result {
                case .success:
                    if let data = response.data {
                        do {
                            self?.details = try JSONDecoder().decode(MovieDetail.self, from: data)
                            self?.movie = self?.details
                            //print(movieJson)
                            self?.updateUI()
                        } catch let JSONError {
                            print(JSONError)
                        }
                    }
                case .failure:
                    print("Failed to retrieve data!")
                }
            }
        }
    }
    
    private func updateUI() {
        if let movie = movie {
            let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.backdrop ?? ""))
            imageView.kf.setImage(with: posterURL)
            ratingLabel.text = "\(movie.rating ?? 0)"
            titleLabel.text = movie.title
            releaseDateLabel.text = movie.releaseDate
            descriptionLabel.text = movie.overview
            self.navigationItem.title = movie.title
        }
    }
}
