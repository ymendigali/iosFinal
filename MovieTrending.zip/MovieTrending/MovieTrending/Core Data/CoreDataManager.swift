//
//  CoreDataManager.swift
//  MovieTrending
//
//  Created by Yersultan Mendigali on 03.06.2021.
//

import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MovieModel")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    private init() {}
    
    func save() {
        let context = persistentContainer.viewContext
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
    
    
    func addMovie(_ movie: MovieEntity.Movie) {
        let context = persistentContainer.viewContext
        context.perform {
            let newMovie = TrendingMovieEntity(context: context)
            newMovie.id = Int64(movie.id)
            newMovie.title = movie.title
            newMovie.poster = movie.poster
            newMovie.releaseDate = movie.releaseDate
            newMovie.rating = movie.rating ?? 0
        }
        save()
    }
    
    func addMovie(_ movie: MovieDetail) {
        let context = persistentContainer.viewContext
        context.perform {
            let newMovie = TrendingMovieEntity(context: context)
            newMovie.id = Int64(movie.id ?? 0)
            newMovie.title = movie.title
            newMovie.poster = movie.poster
            newMovie.releaseDate = movie.releaseDate
            newMovie.rating = movie.rating ?? 0
        }
        save()
    }
    
    
    func findMovie(with id: Int) -> TrendingMovieEntity? {
        let context = persistentContainer.viewContext
        let requestResult: NSFetchRequest<TrendingMovieEntity> = TrendingMovieEntity.fetchRequest()
        requestResult.predicate = NSPredicate(format: "id == %d", id)
        
        do {
            let movies = try context.fetch(requestResult)
            if movies.count > 0 {
                assert(movies.count == 1, "It means DB has duplicates")
                return movies[0]
            }
        } catch {
            print(error)
        }
        
        return nil
    }
    
    
    func deleteMovie(with id: Int) {
        let context = persistentContainer.viewContext
        let movie = findMovie(with: id)
        if let movie = movie {
            context.delete(movie)
            save()
        }
    }
    
    
    func allMovies() -> [MovieEntity.Movie] {
        let context = persistentContainer.viewContext
        let requestResult: NSFetchRequest<TrendingMovieEntity> = TrendingMovieEntity.fetchRequest()

        let movies = try? context.fetch(requestResult)
        
        return movies?.map({ MovieEntity.Movie(movie: $0) }) ?? []
    }
}
