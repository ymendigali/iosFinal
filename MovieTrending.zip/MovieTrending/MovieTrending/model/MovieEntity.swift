//
//  ModelEntity.swift
//  MovieTrending
//
//  Created by Yersultan Mendigali on 27.04.2021.
//

import Foundation

struct MovieEntity: Decodable {
    let results: [Movie]
    
    struct Movie: Decodable {
        let id: Int
        let poster: String?
        let title: String?
        let releaseDate: String?
        let rating: Double?
        
        init(movie: TrendingMovieEntity) {
            self.id = Int(movie.id)
            self.title = movie.title
            self.releaseDate = movie.releaseDate
            self.poster = movie.poster
            self.rating = movie.rating
        }
        
        enum CodingKeys: String, CodingKey {
            case id
            case poster = "poster_path"
            case title = "original_title"
            case releaseDate = "release_date"
            case rating = "vote_average"
        }
    }
}

struct MovieDetail: Decodable {
    var id: Int?
    let backdrop: String?
    let poster: String?
    let title: String?
    let releaseDate: String?
    let rating: Double?
    let overview: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case backdrop = "backdrop_path"
        case poster = "poster_path"
        case title = "original_title"
        case releaseDate = "release_date"
        case rating = "vote_average"
        case overview = "overview"
    }
}
