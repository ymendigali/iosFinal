//
//  MovieCell.swift
//  MovieTrending
//
//  Created by Yersultan Mendigali on 27.04.2021.
//

import UIKit
import Kingfisher

protocol MovieDelegate : class {
    func updateTableOnClick(id: Int)
}

class MovieCell: UITableViewCell {
    
    weak var delegate: MovieDelegate?
    
    public static let identifier: String = "MovieCell"

    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var ratingContainerView: UIView!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var movieTitleLabel: UILabel!
    @IBOutlet private weak var releaseDateLabel: UILabel!
    @IBOutlet private weak var favoriteButton: UIButton!
    
    public var movie: MovieEntity.Movie? {
        didSet {
            if let movie = movie {
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                ratingLabel.text = "\(movie.rating ?? 0)"
                movieTitleLabel.text = movie.title
                releaseDateLabel.text = movie.releaseDate
                
                if let _ = CoreDataManager.shared.findMovie(with: movie.id) {
                    favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                } else {
                    favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        posterImageView.layer.cornerRadius = 12
        posterImageView.layer.masksToBounds = true
        posterImageView.backgroundColor = .systemTeal
        ratingContainerView.layer.cornerRadius = 20
        ratingContainerView.layer.masksToBounds = true
        
        //favoriteButton.isHidden = true
    }

    @IBAction func favoriteButtonPressed(_ sender: UIButton) {
        if let movie = movie {
            if let _ = CoreDataManager.shared.findMovie(with: movie.id) {
                CoreDataManager.shared.deleteMovie(with: movie.id)
                delegate?.updateTableOnClick(id: movie.id)
                sender.setImage(UIImage(named: "star"), for: .normal)
            } else {
                CoreDataManager.shared.addMovie(movie)
                sender.setImage(UIImage(named: "starFilled"), for: .normal)
            }
        }
    }
}


